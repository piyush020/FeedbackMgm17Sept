package com.cg.fms.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.fms.dto.Course;
import com.cg.fms.dto.Employee;
import com.cg.fms.dto.FacultySkill;
import com.cg.fms.dto.Feedback;
import com.cg.fms.dto.Training;
import com.cg.fms.exception.FMSException;
import com.cg.fms.service.CourseService;
import com.cg.fms.service.CourseServiceImpl;
import com.cg.fms.service.EmployeeService;
import com.cg.fms.service.EmployeeServiceImpl;
import com.cg.fms.service.FacultySkillService;
import com.cg.fms.service.FacultySkillServiceImpl;
import com.cg.fms.service.FeedbackService;
import com.cg.fms.service.FeedbackServiceImpl;
import com.cg.fms.service.ParticipantEnrollmentService;
import com.cg.fms.service.ParticipantEnrollmentServiceImpl;
import com.cg.fms.service.TrainingService;
import com.cg.fms.service.TrainingServiceImpl;

public class AdminHandler {
	
	Employee admin;
	CourseService courseService = null;
	ParticipantEnrollmentService partcipantEService = null;
	TrainingService trainingService = null;
	FeedbackService feedbackService = null;
	EmployeeService employeeService = null;
	FacultySkillService facultySkillService = null;
	
	public AdminHandler(Employee employee) {
		super();
		admin = employee;
		courseService = new CourseServiceImpl();
		partcipantEService = new ParticipantEnrollmentServiceImpl();
		trainingService = new TrainingServiceImpl();
		feedbackService = new FeedbackServiceImpl();
		employeeService = new EmployeeServiceImpl();
		facultySkillService = new FacultySkillServiceImpl();
	}

	public void start() throws FMSException {
		System.out.println("\n");
		System.out.println("Welcome " + admin.getEmployeeName());
		System.out.println("What do you want to do");
		System.out.println("1.	Faculty skill Maintenance\r\n" + 
				"2.	Course Maintenance\r\n" + 
				"3.	View Feedback Report\r\n"
				+ "4. \tLogout\n" );
		//all menu items, switch case 
		
		Scanner sc = new Scanner(System.in);
		int choice = sc.nextInt();
		
		switch (choice) 
		{
		case 1:
			displayFacultySkillPage();
			break;
		
		case 2:
			displayCourseMainPage();
			break;
			
		case 3:
			displayFeedbackReportPage();
			break;
			
		case 4:
			MainClass.main(null);
			
			
		default:
			break;
		}
		
	}
	
	public void displayCourseMainPage() throws FMSException 
	{
		Scanner sc = new Scanner(System.in);
		boolean flag = true;
		
		do 
		{
			System.out.println("Welcome to Course Maintenance page");
			System.out.println("What do you want to do");
			System.out.println("1. Get All Courses\r\n"
					+ "2. Add Course\r\n"
					+ "3. Edit Course\r\n"
					+ "4. Exit");
			
			int key = sc.nextInt();
			
			switch (key)
			{
			case 1:
				ArrayList<Course> courseList = courseService.getAllCourse();
				for(Course course : courseList)
				{
					System.out.println(course.getCourseId()+"\t"+course.getCourseName()+"\t"+course.getNoOfDays());
				}
				break;
				
			case 2:
				System.out.println("Enter course name : ");
				String courseName = sc.next();
				System.out.println("Enter course duration : ");
				int courseDuration = sc.nextInt();
				Course newCourse = new Course( courseName, courseDuration);
				Course addedCourse = courseService.addCourse(newCourse);
				if(addedCourse!=null)
				{
					System.out.println("Course Successfully added.");
				}
				else
				{
					System.out.println("Not added");
				}
				break;
				
			case 3:
				System.out.println("Enter Course Id : ");
				int id = sc.nextInt();
				Course course = courseService.getCourseById(id);
				if(course!=null)
				{
					editCourse(course);
				}
				else
				{
					System.out.println("Not found");
				}
				break;
			
			case 4 :
				flag = false;
				break;
			
			default:
				break;
			}
		} while (flag);
			
		
		
		
		
		
		
	}
	public void editCourse(Course course) throws FMSException
	{
		Scanner sc = new Scanner(System.in);
		System.out.println(course);
		boolean flag = true;
		do 
		{
			System.out.println("What do you want to edit?");
			System.out.println("1. Course Name\r\n2. Course Duration\r\n3. Exit");
			int ch1 = sc.nextInt();
			switch (ch1) {
			case 1:
				System.out.println("Enter updated course name : ");
				String CourseName = sc.next();
				Course editedCourse1 = new Course(course.getCourseId(),CourseName, course.getNoOfDays());
				Course newCourse1 = courseService.updateCourse(editedCourse1);
				if(newCourse1!=null)
				{
					System.out.println("Updated");
				}
				else
				{
					System.out.println("Not updated");
				}
				break;
				
			case 2:
				System.out.println("Enter updated duration : ");
				int courseDuration = sc.nextInt();
				Course editedCourse2 = new Course(course.getCourseId(),course.getCourseName(), courseDuration);
				Course newCourse2 = courseService.updateCourse(editedCourse2);
				if(newCourse2!=null)
				{
					System.out.println("Updated");
				}
				else
				{
					System.out.println("Not updated");
				}
				break;
			
			case 3 :
				flag = false;
				break;
				
			default:
				break;
			
		}
		} while (flag);
			
		
	}
	
	public void displayFeedbackReportPage() throws FMSException 
	{
		boolean flag = true;
		Scanner sc = new Scanner(System.in);
		System.out.println("Welcome to Feedback Report page");
		System.out.println("What do you want to do");
		System.out.println("1. \tGet All Feedback\n"
				+ "2. \tGet Feedback\n"
				+ "3. \tGet Feedback Defaulters");
		int ch = sc.nextInt();
		do 
		{
			switch (ch) 
			{
			case 1:
				ArrayList<Feedback> feedbackList = feedbackService.getAllFeedbacks();
				System.out.println(feedbackList);
				break;
			case 2:
				System.out.println("Enter trainer name : ");
				String trainerName = sc.next();
				ArrayList<Training> list = trainingService.getTrainingByFacultyId(employeeService.getEmployeeByName(trainerName).getEmployeeId());
				for(Training training : list)
				{
					System.out.println(feedbackService.getFeedbackByTrainingId(training.getTrainingCode()));
				}
//				ArrayList<Feedback> listByTrainingId = feedbackService.getFeedbackByTrainingId(id);
//				System.out.println(listByTrainingId);
				break;
			
			case 3:
				System.out.println("Feedback Defaulters");
				ArrayList<Feedback> defaultersList = feedbackService.getDefaulters();
				System.out.println(defaultersList);
			
			case 4:
				flag=false;
				break;
			
			default:
				break;
			}
		} while (flag);
		
	}
	
	public void displayFacultySkillPage() throws FMSException
	{
		System.out.println("Welcome to Faculty Skill Maintenance page");
		ArrayList<FacultySkill> facultySkillList = facultySkillService.getAllFacultySkills();
		ArrayList<Course> courseList = courseService.getAllCourse();
		while(true) {
		System.out.println("What do you want to do");
		Scanner sc = new Scanner(System.in);
		int ch = sc.nextInt();
		switch (ch) {
		case 1:
			for(FacultySkill facultyskill : facultySkillList)
			{
				System.out.println(facultyskill.getFacultyId()+"\t"+employeeService.getEmployeeById(facultyskill.getFacultyId()).getEmployeeName()+"\t"+facultyskill.getSkillSet());
			}
			break;
			
		case 2:
			for(Course course : courseList)
			{
				System.out.println(course.getCourseId()+"\t"+course.getCourseName()+"\t"+course.getNoOfDays());
			}
			break;
			
		case 3:
			addTrain();
			break;
			
		default:
			break;
		}
		}
		
	}
	
	public void addTrain() throws FMSException
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Faculty Id : ");
		int FacultyId = sc.nextInt();
		System.out.println("Enter Course Id : ");
		int courseId = sc.nextInt();
		System.out.println("Enter Start Date : ");
		String sDate = sc.next();
		System.out.println("Enter End Date : ");
		String eDate = sc.next();
		DateTimeFormatter format=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate startDate = LocalDate.parse(sDate, format);
		LocalDate endDate = LocalDate.parse(eDate, format);
		Training training = new Training(courseId, FacultyId, startDate, endDate);
		Training addedTraining = trainingService.addTraining(training);
		if(addedTraining!=null)
		{
			System.out.println("Training added");
		}
		else
		{
			System.out.println("Training not added");
		}
	}
	
}
